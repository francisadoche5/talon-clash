import { useState, useEffect } from 'react';
import { login, getPlayer } from './api';
import Lobby from './components/Lobby';
import Market from './components/Market';
import Inventory from './components/Inventory';
import Clans from './components/Clans';
import SkillTree from './components/SkillTree';
import Earn from './components/Earn';

const TABS = [
  { id: 'market', label: 'Market', icon: '🏪' },
  { id: 'inventory', label: 'Inventory', icon: '🎒' },
  { id: 'lobby', label: 'Lobby', icon: '⚔️' },
  { id: 'clans', label: 'Clans', icon: '👥' },
  { id: 'skills', label: 'Skills', icon: '🌳' },
  { id: 'earn', label: 'Earn', icon: '💰' }
];

export default function App() {
  const [player, setPlayer] = useState(null);
  const [telegramUser, setTelegramUser] = useState(null);
  const [activeTab, setActiveTab] = useState('lobby');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => { initApp(); }, []);

  async function initApp() {
    try {
      const tg = window.Telegram?.WebApp;
      if (tg) {
        tg.ready();
        tg.expand();
      }

      const tgUser = tg?.initDataUnsafe?.user || {
        id: 123456789,
        first_name: 'TestPlayer',
        username: 'testplayer'
      };

      setTelegramUser(tgUser);

      const res = await login(tgUser);
      if (res.data?.player) {
        setPlayer(res.data.player);
      } else {
        setError('Login failed. Please try again.');
      }
    } catch (err) {
      console.error('Init error:', err);
      setError('Cannot connect to server. Please try again.');
    } finally {
      setLoading(false);
    }
  }

  // FIX: Use getPlayer with telegram_id instead of calling login again
  async function refreshPlayer() {
    if (!player?.telegram_id) return;
    try {
      const res = await getPlayer(player.telegram_id);
      if (res.data?.player) setPlayer(res.data.player);
    } catch (err) {
      console.error('Refresh error:', err);
    }
  }

  if (loading) return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-amber-950">
      <div className="text-6xl mb-4 animate-bounce">🦅</div>
      <div className="text-amber-200 text-xl font-bold">Talon Clash</div>
      <div className="text-amber-400 text-sm mt-2">Loading...</div>
      <div className="mt-6 w-48 h-2 bg-amber-900 rounded-full overflow-hidden">
        <div className="h-full bg-amber-400 rounded-full animate-pulse" style={{width:'75%'}}></div>
      </div>
    </div>
  );

  if (error) return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-amber-950 p-6">
      <div className="text-4xl mb-4">❌</div>
      <div className="text-red-400 text-center mb-4">{error}</div>
      <button onClick={() => { setError(null); setLoading(true); initApp(); }}
        className="bg-amber-600 text-white px-6 py-3 rounded-full font-bold">
        Try Again
      </button>
    </div>
  );

  if (!player) return null;

  const energyPercent = Math.min(100, ((player.energy || 0) / (player.max_energy || 400)) * 100);

  return (
    <div className="flex flex-col min-h-screen bg-amber-950 max-w-md mx-auto">
      {/* Header */}
      <div className="bg-amber-900 px-4 py-2 flex items-center justify-between sticky top-0 z-40 border-b border-amber-700">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-full bg-amber-600 flex items-center justify-center text-sm font-black border-2 border-amber-400">
            {player.level}
          </div>
          <div>
            <div className="text-amber-100 text-sm font-bold leading-tight">
              {(player.display_name || 'Player').substring(0, 12)}
            </div>
            <div className="w-20 h-1.5 bg-amber-800 rounded-full mt-0.5">
              <div className="h-full bg-green-400 rounded-full transition-all"
                style={{width: `${Math.min(100, ((player.xp||0)/(player.xp_needed||100))*100)}%`}}></div>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2 text-xs">
          <div className="flex items-center gap-1 bg-amber-800 rounded-full px-2 py-1">
            <span>⚡</span>
            <span className="text-yellow-300 font-bold">{Math.floor(player.energy||0)}/{player.max_energy||400}</span>
          </div>
          <div className="flex items-center gap-1 bg-amber-800 rounded-full px-2 py-1">
            <span>🪶</span>
            <span className="text-green-300 font-bold">{(player.feathers||0).toLocaleString()}</span>
          </div>
        </div>
      </div>

      {/* Evolution + Power bar */}
      <div className="bg-amber-800 px-4 py-1.5 flex items-center justify-between text-xs">
        <span className="text-amber-300 font-bold">{player.evolution_name || 'Hatchling'}</span>
        <span className="text-amber-400">⚡{Math.floor(player.energy||0)} • 🌾{(player.food||0).toLocaleString()} • 🔨{player.hammers||0}</span>
        <span className="text-amber-300 font-bold">Power: {(player.power||0).toLocaleString()}</span>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-y-auto pb-16">
        {activeTab === 'lobby' && <Lobby player={player} onRefresh={refreshPlayer} />}
        {activeTab === 'market' && <Market player={player} onRefresh={refreshPlayer} />}
        {activeTab === 'inventory' && <Inventory player={player} onRefresh={refreshPlayer} />}
        {activeTab === 'clans' && <Clans player={player} onRefresh={refreshPlayer} />}
        {activeTab === 'skills' && <SkillTree player={player} onRefresh={refreshPlayer} />}
        {activeTab === 'earn' && <Earn player={player} onRefresh={refreshPlayer} />}
      </div>

      {/* Bottom Nav */}
      <div className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-amber-900 border-t border-amber-700 flex z-40">
        {TABS.map(tab => (
          <button key={tab.id} onClick={() => setActiveTab(tab.id)}
            className={`flex-1 py-2 flex flex-col items-center gap-0.5 transition-all ${
              activeTab === tab.id ? 'bg-amber-700 text-white' : 'text-amber-500 hover:text-amber-300'
            }`}>
            <span className="text-lg">{tab.icon}</span>
            <span className="text-xs leading-tight">{tab.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
