# 🦅 Talon Clash Setup Guide
## Follow these steps IN ORDER

---

## STEP 1: Run SQL in Supabase (CRITICAL - do this first!)

1. Go to supabase.com → your talon-clash project
2. Click **SQL Editor** in left sidebar
3. Paste the entire contents of `backend/create-admin.sql`
4. Click **Run**
5. You should see: `Setup complete! Login: admin / TalonAdmin2024!`

---

## STEP 2: Get your Supabase Service Role Key

1. Go to Supabase → Settings → API Keys
2. Click the **Legacy anon, service** tab
3. Click **Reveal** next to `service_role`
4. Copy that key - you need it for Render

---

## STEP 3: Add Service Role Key to Render

1. Go to render.com → talon-clash service
2. Click **Environment** in left sidebar
3. Click **Add Environment Variable**
4. Name: `SUPABASE_SERVICE_KEY`
5. Value: paste your service role key
6. Click **Save Changes**

---

## STEP 4: Upload code to GitHub

1. Download and extract the zip
2. Go to github.com → francisadoche5/talon-clash
3. Upload all files (drag and drop)
4. Commit the changes

---

## STEP 5: Deploy Admin Panel to Vercel

1. Go to vercel.com
2. Click **Add New Project**
3. Select `talon-clash` repo
4. Set **Root Directory** to `admin`
5. Add environment variable:
   - `VITE_BACKEND_URL` = `https://talon-clash.onrender.com`
6. Click **Deploy**
7. Note your admin URL (e.g. talon-clash-admin.vercel.app)

---

## STEP 6: Update Frontend Vercel deployment

1. Go to vercel.com → talon-clash project
2. Click **Settings** → **Environment Variables**
3. Make sure these exist:
   - `VITE_BACKEND_URL` = `https://talon-clash.onrender.com`
   - `VITE_SUPABASE_URL` = `https://tpvmpwolclilfbujiimv.supabase.co`
   - `VITE_SUPABASE_ANON_KEY` = your anon key
4. Go to **Deployments** → **Redeploy**

---

## STEP 7: Set up Telegram Bot Mini App

1. Open Telegram → search @BotFather
2. Send `/mybots`
3. Select your TalonClash bot
4. Click **Bot Settings** → **Menu Button**
5. Set URL to: `https://talon-clash.vercel.app`
6. Also send `/newapp` to create the Mini App

---

## STEP 8: Test the game

1. Open Telegram → find your bot
2. Send `/start`
3. Tap the Play button
4. If it loads - you're live! 🎉

---

## Admin Panel Login
- URL: your admin vercel URL
- Username: `admin`
- Password: `TalonAdmin2024!`
- **Change password immediately after first login!**

---

## If something breaks
- Check Render logs: render.com → talon-clash → Logs
- Check Supabase: supabase.com → your project → Logs
