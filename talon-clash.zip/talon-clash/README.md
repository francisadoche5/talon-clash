# 🦅 Talon Clash

A Telegram Mini App battle game where birds evolve from Hatchlings to Shadow Eagles!

## Structure
- `/backend` — Node.js Express API + Telegram Bot
- `/frontend` — React game UI (Telegram Mini App)
- `/admin` — Admin dashboard

## Setup
See deployment guides in each folder.

## Config Files (change game values here)
- `backend/config/evolutions.js` — Bird evolution tiers & power thresholds
- `backend/config/battles.js` — Battle rules, energy costs, rewards
- `backend/config/store.js` — Store items and chest rewards
- `backend/config/skills.js` — Skill tree values
