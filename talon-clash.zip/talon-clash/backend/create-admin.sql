-- ================================================
-- RUN THIS IN SUPABASE SQL EDITOR
-- Do this BEFORE launching the game
-- ================================================

-- Fix players table id auto-increment
CREATE SEQUENCE IF NOT EXISTS players_id_seq START 1;
ALTER TABLE players ALTER COLUMN id SET DEFAULT nextval('players_id_seq');

-- Disable RLS on all tables (our API handles security)
ALTER TABLE players DISABLE ROW LEVEL SECURITY;
ALTER TABLE items DISABLE ROW LEVEL SECURITY;
ALTER TABLE player_skills DISABLE ROW LEVEL SECURITY;
ALTER TABLE battles DISABLE ROW LEVEL SECURITY;
ALTER TABLE clans DISABLE ROW LEVEL SECURITY;
ALTER TABLE clan_members DISABLE ROW LEVEL SECURITY;
ALTER TABLE quests DISABLE ROW LEVEL SECURITY;
ALTER TABLE player_quests DISABLE ROW LEVEL SECURITY;
ALTER TABLE store_items DISABLE ROW LEVEL SECURITY;
ALTER TABLE tournaments DISABLE ROW LEVEL SECURITY;
ALTER TABLE tournament_entries DISABLE ROW LEVEL SECURITY;
ALTER TABLE announcements DISABLE ROW LEVEL SECURITY;
ALTER TABLE game_config DISABLE ROW LEVEL SECURITY;
ALTER TABLE evolution_tiers DISABLE ROW LEVEL SECURITY;
ALTER TABLE adquests DISABLE ROW LEVEL SECURITY;
ALTER TABLE referrals DISABLE ROW LEVEL SECURITY;
ALTER TABLE admin_users DISABLE ROW LEVEL SECURITY;

-- Create admin account
-- Username: admin
-- Password: TalonAdmin2024!
-- IMPORTANT: Change this password after first login!
INSERT INTO admin_users (username, password_hash)
VALUES ('admin', '$2a$10$rBBU5M4BNzQJ6FzWs.NBBuF7p0H7gW5VGXXz4v1PzKhIWZCbQ2n2G')
ON CONFLICT (username) DO NOTHING;

SELECT 'Setup complete! Login: admin / TalonAdmin2024!' as status;
