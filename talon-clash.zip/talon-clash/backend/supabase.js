const { createClient } = require('@supabase/supabase-js');
require('dotenv').config();

// Backend uses service role key to bypass RLS
// This is safe because backend is never exposed to users directly
const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY || process.env.SUPABASE_ANON_KEY
);

module.exports = supabase;
