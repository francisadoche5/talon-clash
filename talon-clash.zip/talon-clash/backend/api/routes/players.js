const router = require('express').Router();
const { getOrCreatePlayer, calculatePower, regenEnergy } = require('../../modules/players');
const supabase = require('../../supabase');

// Login / get-or-create player
router.post('/login', async (req, res) => {
  try {
    const { telegram_user } = req.body;
    if (!telegram_user) return res.status(400).json({ error: 'No telegram user provided' });

    const player = await getOrCreatePlayer(telegram_user);
    if (!player) return res.status(500).json({ error: 'Failed to create player' });

    await regenEnergy(player.telegram_id);
    await calculatePower(player.telegram_id);

    const { data: updatedPlayer } = await supabase
      .from('players').select('*').eq('telegram_id', player.telegram_id).single();

    res.json({ success: true, player: updatedPlayer });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ error: err.message });
  }
});

// FIX: Leaderboard MUST come before /:id to avoid route conflict
router.get('/leaderboard', async (req, res) => {
  try {
    const { data: top } = await supabase
      .from('players')
      .select('telegram_id, display_name, power, evolution_name, evolution_tier, glory, battles_won')
      .order('power', { ascending: false })
      .limit(100);
    res.json({ success: true, leaderboard: top || [] });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get player by telegram_id
router.get('/:id', async (req, res) => {
  try {
    await regenEnergy(req.params.id);
    const { data: player } = await supabase
      .from('players').select('*').eq('telegram_id', req.params.id).single();
    if (!player) return res.status(404).json({ error: 'Player not found' });
    res.json({ success: true, player });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
