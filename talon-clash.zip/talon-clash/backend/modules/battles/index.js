const supabase = require('../../supabase');
const { BATTLE_CONFIG, STAT_CONFIG, CRIT_CONFIG, BLOCK_CONFIG, rollBonusReward } = require('../../config/battles');
const { calculatePower } = require('../players');

async function getPlayerStats(telegramId) {
  const { data: player } = await supabase.from('players').select('*').eq('telegram_id', telegramId).single();
  if (!player) return null;

  const { data: skills } = await supabase.from('player_skills').select('*').eq('player_id', telegramId).single();
  const { data: items } = await supabase.from('items').select('*').eq('player_id', telegramId).eq('is_equipped', true);

  let attack = STAT_CONFIG.baseAttack + (player.level * STAT_CONFIG.attackPerLevel);
  let hp = STAT_CONFIG.baseHP + (player.level * STAT_CONFIG.hpPerLevel);
  let defense = STAT_CONFIG.baseDefense + (player.level * STAT_CONFIG.defensePerLevel);
  let critChance = CRIT_CONFIG.baseCritChance;
  let blockChance = BLOCK_CONFIG.baseBlockChance;

  if (items && items.length > 0) {
    items.forEach(item => {
      attack += (item.attack_bonus || 0);
      hp += (item.hp_bonus || 0);
      defense += (item.defense_bonus || 0);
    });
  }

  if (skills) {
    attack += (skills.attack_level || 0) * 5;
    hp += (skills.hp_level || 0) * 30;
    defense += (skills.defense_level || 0) * 3;
    critChance += (skills.crit_level || 0) * 2;
  }

  return { player, attack, hp, defense, critChance, blockChance };
}

async function findOpponent(telegramId, mode) {
  const { data: player } = await supabase.from('players').select('power').eq('telegram_id', telegramId).single();
  if (!player) return null;

  const powerRange = mode === 'epic' ? 5000 : 3000;
  const minPower = Math.max(0, player.power - powerRange);
  const maxPower = player.power + powerRange;

  const { data: opponents } = await supabase
    .from('players')
    .select('*')
    .neq('telegram_id', telegramId)
    .eq('is_banned', false)
    .gte('power', minPower)
    .lte('power', maxPower)
    .limit(10);

  if (!opponents || opponents.length === 0) {
    // Find any player if no one in range
    const { data: anyOpponents } = await supabase
      .from('players')
      .select('*')
      .neq('telegram_id', telegramId)
      .eq('is_banned', false)
      .limit(5);

    if (!anyOpponents || anyOpponents.length === 0) return null;
    return anyOpponents[Math.floor(Math.random() * anyOpponents.length)];
  }

  return opponents[Math.floor(Math.random() * opponents.length)];
}

function simulateBattle(attackerStats, defenderStats) {
  let attackerHP = attackerStats.hp;
  let defenderHP = defenderStats.hp;
  const log = [];
  let round = 0;

  while (attackerHP > 0 && defenderHP > 0 && round < 50) {
    round++;

    // Attacker hits defender
    let damage = Math.max(1, attackerStats.attack - Math.floor(defenderStats.defense * 0.5));
    const isCrit = Math.random() * 100 < attackerStats.critChance;
    const isBlocked = Math.random() * 100 < defenderStats.blockChance;

    if (isCrit) damage = Math.floor(damage * CRIT_CONFIG.critMultiplier);
    if (isBlocked) damage = Math.floor(damage * (1 - BLOCK_CONFIG.blockReduction));
    damage = Math.max(1, damage + Math.floor(Math.random() * 6) - 3);

    defenderHP -= damage;
    log.push({ round, attacker: 'player', damage, isCrit, isBlocked });
    if (defenderHP <= 0) break;

    // Defender hits attacker
    let damage2 = Math.max(1, defenderStats.attack - Math.floor(attackerStats.defense * 0.5));
    const isCrit2 = Math.random() * 100 < defenderStats.critChance;
    const isBlocked2 = Math.random() * 100 < attackerStats.blockChance;

    if (isCrit2) damage2 = Math.floor(damage2 * CRIT_CONFIG.critMultiplier);
    if (isBlocked2) damage2 = Math.floor(damage2 * (1 - BLOCK_CONFIG.blockReduction));
    damage2 = Math.max(1, damage2 + Math.floor(Math.random() * 6) - 3);

    attackerHP -= damage2;
    log.push({ round, attacker: 'opponent', damage: damage2, isCrit: isCrit2, isBlocked: isBlocked2 });
  }

  return {
    playerWon: attackerHP > 0,
    playerHPEnd: Math.max(0, Math.floor(attackerHP)),
    opponentHPEnd: Math.max(0, Math.floor(defenderHP)),
    log
  };
}

async function runBattle(telegramId, mode = 'normal') {
  const config = BATTLE_CONFIG[mode];
  if (!config) return { error: 'Invalid battle mode' };

  // Check energy
  const { data: player } = await supabase
    .from('players')
    .select('energy, battles_played, battles_won, battles_lost, xp, level, xp_needed, glory, feathers, food, skill_points')
    .eq('telegram_id', telegramId)
    .single();

  if (!player) return { error: 'Player not found' };
  if ((player.energy || 0) < config.energyCost) {
    return { error: 'Not enough energy', energy: player.energy };
  }

  // Find opponent
  const opponent = await findOpponent(telegramId, mode);
  if (!opponent) return { error: 'No opponent found. Play more to unlock matchmaking!' };

  // Get stats
  const playerStats = await getPlayerStats(telegramId);
  const opponentStats = await getPlayerStats(opponent.telegram_id);

  if (!playerStats || !opponentStats) return { error: 'Failed to load battle stats' };

  // Simulate battle
  const result = simulateBattle(playerStats, opponentStats);

  const rewardConfig = result.playerWon ? config.rewards.win : config.rewards.lose;
  const xpEarned = Math.floor((20 + Math.random() * 30) * rewardConfig.xpMultiplier);
  const gloryEarned = Math.floor((10 + Math.random() * 20) * rewardConfig.gloryMultiplier);
  const foodEarned = rewardConfig.baseFood;
  const feathersEarned = rewardConfig.baseFeathers || 0;

  // Bonus reward on win
  let bonusReward = null;
  if (result.playerWon) {
    bonusReward = rollBonusReward(config.bonusRewards);
  }

  // Level up calculation
  let newXP = (player.xp || 0) + xpEarned;
  let newLevel = player.level || 1;
  let newXPNeeded = player.xp_needed || 100;
  let leveledUp = false;
  let skillPointsEarned = 0;

  if (newXP >= newXPNeeded) {
    newXP -= newXPNeeded;
    newLevel += 1;
    newXPNeeded = Math.floor(newXPNeeded * 1.3);
    leveledUp = true;
    skillPointsEarned = 1; // 1 skill point per level
  }

  // Update player stats
  const updates = {
    energy: Math.max(0, (player.energy || 0) - config.energyCost),
    xp: newXP,
    level: newLevel,
    xp_needed: newXPNeeded,
    glory: (player.glory || 0) + gloryEarned,
    feathers: (player.feathers || 0) + feathersEarned,
    food: (player.food || 0) + foodEarned,
    battles_played: (player.battles_played || 0) + 1,
    battles_won: result.playerWon ? (player.battles_won || 0) + 1 : (player.battles_won || 0),
    battles_lost: result.playerWon ? (player.battles_lost || 0) : (player.battles_lost || 0) + 1,
    skill_points: (player.skill_points || 0) + skillPointsEarned,
    updated_at: new Date().toISOString()
  };

  // Apply bonus reward
  if (bonusReward) {
    if (bonusReward.type === 'feathers') updates.feathers += bonusReward.amount;
    else if (bonusReward.type === 'small_booster' || bonusReward.type === 'medium_booster') {
      const boostAmt = bonusReward.type === 'small_booster' ? 50 : 250;
      updates.energy = Math.min(playerStats.player.max_energy, updates.energy + boostAmt);
    } else if (bonusReward.type === 'hammer' || bonusReward.type === 'golden_talon') {
      updates.hammers = (playerStats.player.hammers || 0) + bonusReward.amount;
    }
  }

  await supabase.from('players').update(updates).eq('telegram_id', telegramId);

  // Save battle record
  await supabase.from('battles').insert({
    player_id: telegramId,
    opponent_id: opponent.telegram_id,
    mode,
    winner_id: result.playerWon ? telegramId : opponent.telegram_id,
    player_hp_start: playerStats.hp,
    opponent_hp_start: opponentStats.hp,
    player_hp_end: result.playerHPEnd,
    opponent_hp_end: result.opponentHPEnd,
    xp_earned: xpEarned,
    glory_earned: gloryEarned,
    feathers_earned: feathersEarned,
    food_earned: foodEarned,
    bonus_reward: bonusReward?.type || null,
    bonus_amount: bonusReward?.amount || null
  });

  // Recalculate power
  await calculatePower(telegramId);

  return {
    success: true,
    playerWon: result.playerWon,
    opponent: {
      telegram_id: opponent.telegram_id,
      display_name: opponent.display_name,
      power: opponent.power,
      evolution_name: opponent.evolution_name
    },
    playerStats: { hp: playerStats.hp, attack: playerStats.attack },
    opponentStats: { hp: opponentStats.hp, attack: opponentStats.attack },
    playerHPEnd: result.playerHPEnd,
    opponentHPEnd: result.opponentHPEnd,
    rewards: {
      xp: xpEarned,
      glory: gloryEarned,
      feathers: feathersEarned,
      food: foodEarned,
      bonus: bonusReward
    },
    levelUp: leveledUp,
    newLevel,
    log: result.log.slice(0, 10) // limit log size
  };
}

module.exports = { runBattle };
